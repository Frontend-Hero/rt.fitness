<?php 
$args = array
(
    'menu' 			  => 3,
    'container' 	  => 'nav',
    'container_id'	  => 'contact-menu',
    'container_class' => ''
);
wp_nav_menu( $args ); ?> 