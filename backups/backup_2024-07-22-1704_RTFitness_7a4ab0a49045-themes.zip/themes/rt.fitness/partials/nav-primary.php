<?php 
$args = array
(
    'menu' 			  => 2,
    'container' 	  => 'nav',
    'container_id'	  => 'nav-primary',
    'container_class' => ''
);
wp_nav_menu( $args ); ?>