<div id="social-follow">
    <div class="wrapper">
        <div class="rt-flex">
            <h4>Follow along, and be social</h4>
            <ul class="rt-socials">
                <li><a target="_blank" href="https://www.instagram.com/rtfitness_1/"><i class="fa fa-instagram"></i></a></li>
                <li><a target="_blank" href="https://www.facebook.com/richard.turner34"><i class="fa fa-facebook"></i></a></li>
                <li class="strava">
                    <a target="_blank" href="https://www.strava.com/athletes/43255565">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/icon-strava.svg">
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>